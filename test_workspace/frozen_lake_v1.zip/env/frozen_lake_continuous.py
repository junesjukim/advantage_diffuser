import gymnasium as gym
import numpy as np
from gymnasium.spaces import Box

class FrozenLakeContinuous(gym.Env):
    """
    A continuous version of the FrozenLake environment.

    The agent starts at (-0.75, -0.75) and needs to reach the goal at (0.75, 0.75).
    There are four circular "lakes" on the map that the agent should avoid.
    """
    def __init__(self):
        super().__init__()

        # Define observation and action spaces
        self.observation_space = Box(low=-1.0, high=1.0, shape=(2,), dtype=np.float32)
        self.action_space = Box(low=-1.0, high=1.0, shape=(2,), dtype=np.float32)

        # Environment parameters
        self.lake_centers = np.array([
            [-0.25, -0.25],
            [-0.25, 0.75],
            [0.25, 0.75],
            [0.75, -0.75]
        ], dtype=np.float32)
        self.lake_radius = 0.25
        self.goal = np.array([0.75, 0.75], dtype=np.float32)
        
        self.state = None

    def _is_on_lake(self, state):
        """Checks if a given state is inside any of the lakes."""
        distances = np.linalg.norm(state - self.lake_centers, axis=1)
        return np.any(distances < self.lake_radius)

    def reset(self, *, seed=None, options=None):
        """
        Resets the environment to the starting state.
        """
        super().reset(seed=seed)
        self.state = np.array([-0.75, -0.75], dtype=np.float32)
        return self.state.copy(), {}

    def step(self, action):
        """
        Executes one time step in the environment.
        """
        is_on_lake = self._is_on_lake(self.state)

        # Calculate reward
        distance_to_goal = np.linalg.norm(self.state - self.goal)
        reward = -distance_to_goal.item() if not is_on_lake else -4.0

        if not is_on_lake:
            action = np.asarray(action, dtype=np.float32).copy()
            action_norm = np.linalg.norm(action)
            if action_norm > 1.0:
                action = action / action_norm

            w = self.np_random.standard_normal(size=action.shape, dtype=np.float32)
            self.state += 0.25 * (action + action_norm * w)
            self.state = np.clip(self.state, -1.0, 1.0)
        
        return self.state.copy(), reward, False, False, {}

gym.register(
    id='FrozenLakeContinuous-v1',
    entry_point='env.frozen_lake_continuous:FrozenLakeContinuous',
    max_episode_steps=16,
)